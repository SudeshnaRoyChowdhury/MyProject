import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import { StudentModel} from './student.model'
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  formValue !: FormGroup;
  studentModelObj: StudentModel = new StudentModel();
  showAdd!:boolean;
  showUpdate!:boolean;
  studentData!: any;
  constructor(private formbuilder: FormBuilder,
    private api:ApiService) { }

  ngOnInit(): void {

    this.formValue = this.formbuilder.group({
      name:[''],
      email:[''],
      mobile:[''],
      dept:[''],
      marks:['']
    })
    this.getAllStudent();
  }
clickAddStudent(){
  this.formValue.reset();
  this.showAdd=true;
  this.showUpdate=false;
}
  postStudentDetails(){
    this.studentModelObj.name = this.formValue.value.name;
    this.studentModelObj.email = this.formValue.value.email;
    this.studentModelObj.mobile = this.formValue.value.mobile;
    this.studentModelObj.dept = this.formValue.value.dept;
    this.studentModelObj.marks = this.formValue.value.marks;

    this.api.postStudent(this.studentModelObj)
    .subscribe(res =>{
      console.log("res");
      alert("Student Added Successfully");
      let ref = document.getElementById("cancel");
      ref?.click();
      this.formValue.reset();
      this.getAllStudent();
    },
    err =>{
      alert("Something went wrong");
    })
  }

  getAllStudent(){
    this.api.getStudent()
    .subscribe(res =>{
      this.studentData = res;
    })
  }
  deleteStudent(row:any){
    this.api.deleteStudent(row.id)
    .subscribe(res=>{
      alert("Student Deleted");
      this.getAllStudent();
    })
  }
  onEdit(row:any){
    this.showAdd=false;
    this.showUpdate=true;
    this.studentModelObj.id=row.id;
    this.formValue.controls['name'].setValue(row.name);
    this.formValue.controls['email'].setValue(row.email);
    this.formValue.controls['mobile'].setValue(row.mobile);
    this.formValue.controls['dept'].setValue(row.dept);
    this.formValue.controls['marks'].setValue(row.marks);

  }

  updateStudentDetails(){
    this.studentModelObj.name = this.formValue.value.name;
    this.studentModelObj.email = this.formValue.value.email;
    this.studentModelObj.mobile = this.formValue.value.mobile;
    this.studentModelObj.dept = this.formValue.value.dept;
    this.studentModelObj.marks = this.formValue.value.marks;
    this.api.updateStudent(this.studentModelObj,this.studentModelObj.id)
    .subscribe(res=>{
      alert("Detels updated Successfully");
      let ref = document.getElementById("cancel");
      ref?.click();
      this.formValue.reset();
      this.getAllStudent();
    })
  }
}
