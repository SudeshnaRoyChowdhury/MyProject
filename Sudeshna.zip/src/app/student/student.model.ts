export class StudentModel{
    id : number=0;
    name : string='';
    email: string='';
    mobile:number=0;
    dept:string='';
    marks:string='';
}